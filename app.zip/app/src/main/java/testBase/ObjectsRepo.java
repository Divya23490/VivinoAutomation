package testBase;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pageObjects.EnterSearchBoxPageObjects;

public class ObjectsRepo {

	public static ExtentReports extent; 
	public static ExtentTest test; 
	public static EnterSearchBoxPageObjects enterSearch;
}
